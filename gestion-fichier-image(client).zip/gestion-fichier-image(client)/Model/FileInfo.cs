﻿namespace gestion_fichier_image_client_.Model { 

    public class FileInfo
    {
    public long Id { get; set; }
    public string  Name { get; set; } = string.Empty;
    public string ? Url { get; set; } = string.Empty;
    public string? Type { get; set; } = string.Empty;
    }
}
